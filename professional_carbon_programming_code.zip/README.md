# Professional Carbon Programming — Extracted Code Pack

This ZIP contains code snippets extracted chapter-by-chapter from the uploaded manuscript.

## Structure
- One folder per chapter (including INTRODUCTION).
- Inside each folder, files are named `chapter_xx_snippet_N.ext`.
- Extensions are heuristically assigned: `.carbon`, `.cmake`, `.sh`, `.sql`, or `.ics`.

## Notes
- Extraction used simple heuristics (code styles, keywords, braces, and triple backticks). Some prose may be included or some code may be missed if not clearly marked.
- If a chapter showed no detectable code, a `*_placeholder.txt` file is included.

## Manifest

### INTRODUCTION
- introduction_snippet_1.carbon
- introduction_snippet_2.carbon
- introduction_snippet_3.carbon
- introduction_snippet_4.carbon
- introduction_snippet_5.carbon
- introduction_snippet_6.carbon
- introduction_snippet_7.carbon
- introduction_snippet_8.carbon
- introduction_snippet_9.carbon
- introduction_snippet_10.carbon
- introduction_snippet_11.carbon
- introduction_snippet_12.carbon
- introduction_snippet_13.carbon
- introduction_snippet_14.carbon
- introduction_snippet_15.carbon
- introduction_snippet_16.carbon
- introduction_snippet_17.carbon
- introduction_snippet_18.carbon
- introduction_snippet_19.carbon
- introduction_snippet_20.carbon
- introduction_snippet_21.carbon
- introduction_snippet_22.carbon
- introduction_snippet_23.carbon

### Chapter 1
- chapter_1_placeholder.txt

### Chapter 2
- chapter_2_placeholder.txt

### Chapter 3
- chapter_3_placeholder.txt

### Chapter 4
- chapter_4_placeholder.txt

### Chapter 5
- chapter_5_placeholder.txt

### Chapter 6
- chapter_6_placeholder.txt

### Chapter 7
- chapter_7_placeholder.txt

### Chapter 8
- chapter_8_placeholder.txt

### Chapter 9
- chapter_9_placeholder.txt

### Chapter 10
- chapter_10_placeholder.txt

### Chapter 11
- chapter_11_placeholder.txt

### Chapter 12
- chapter_12_placeholder.txt

### Chapter 13
- chapter_13_placeholder.txt

### Chapter 14
- chapter_14_placeholder.txt

### Chapter 15
- chapter_15_placeholder.txt

